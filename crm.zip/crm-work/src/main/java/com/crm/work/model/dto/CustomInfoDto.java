package com.crm.work.model.dto;

import com.crm.work.model.CustomInfo;

public class CustomInfoDto extends CustomInfo {

}
