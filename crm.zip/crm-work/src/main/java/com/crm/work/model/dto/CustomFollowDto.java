package com.crm.work.model.dto;

import com.crm.work.model.CustomFollow;

public class CustomFollowDto extends CustomFollow {
    CustomFollow nextFollow;
}
