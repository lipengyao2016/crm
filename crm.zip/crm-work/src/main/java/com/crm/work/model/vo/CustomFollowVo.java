package com.crm.work.model.vo;

import com.crm.work.model.CustomFollow;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel("跟进阶段展示")
public class CustomFollowVo extends CustomFollow {

    @ApiModelProperty("下一个计划跟进信息")
    CustomFollow nextFollow;
}
