package com.crm.vo;

import com.crm.bean.Role;
import com.crm.bean.Role;

public class RoleVo extends Role {
}