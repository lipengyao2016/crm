package com.crm.vo;

import java.io.Serializable;

import com.crm.bean.Attachment;

@SuppressWarnings("serial")
public class AttachmentVo extends Attachment implements Serializable{
	
}