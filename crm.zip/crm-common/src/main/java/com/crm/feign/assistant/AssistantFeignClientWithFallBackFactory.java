package com.crm.feign.assistant;

public interface AssistantFeignClientWithFallBackFactory extends AssistantFeignClient {

}
