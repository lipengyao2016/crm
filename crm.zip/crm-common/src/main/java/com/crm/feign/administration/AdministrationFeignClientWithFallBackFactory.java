package com.crm.feign.administration;

public interface AdministrationFeignClientWithFallBackFactory extends AdministrationFeignClient {

}
