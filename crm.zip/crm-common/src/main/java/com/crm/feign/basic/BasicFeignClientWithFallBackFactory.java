package com.crm.feign.basic;

public interface BasicFeignClientWithFallBackFactory extends BasicFeignClient {

}
