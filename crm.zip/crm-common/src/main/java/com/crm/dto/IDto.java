package com.crm.dto;

import java.io.Serializable;

public interface IDto extends Serializable {

}
