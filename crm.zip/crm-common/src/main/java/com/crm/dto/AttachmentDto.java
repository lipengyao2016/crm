package com.crm.dto;

import com.crm.bean.Attachment;
import io.swagger.annotations.ApiModel;

@ApiModel
@SuppressWarnings("serial")
public class AttachmentDto extends Attachment{
	 
}