package com.crm.common;

public enum EOrderRule {
	DESC,
	ASC
}
