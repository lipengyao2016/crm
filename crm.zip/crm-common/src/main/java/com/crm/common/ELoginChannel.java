package com.crm.common;

public enum ELoginChannel {
	PC, iOS, Android, WAP
}
