package com.crm.bean.user;

import java.util.Date;

public class Departments {
    private Long id;

    private String name;

    private String description;

    private Long uplevelDepartmentId;

    private Long userOrganizationId;

    private String status;

    private Date createdDt;

    private Date updatedDt;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description == null ? null : description.trim();
    }

    public Long getUplevelDepartmentId() {
        return uplevelDepartmentId;
    }

    public void setUplevelDepartmentId(Long uplevelDepartmentId) {
        this.uplevelDepartmentId = uplevelDepartmentId;
    }

    public Long getUserOrganizationId() {
        return userOrganizationId;
    }

    public void setUserOrganizationId(Long userOrganizationId) {
        this.userOrganizationId = userOrganizationId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status == null ? null : status.trim();
    }

    public Date getCreatedDt() {
        return createdDt;
    }

    public void setCreatedDt(Date createdDt) {
        this.createdDt = createdDt;
    }

    public Date getUpdatedDt() {
        return updatedDt;
    }

    public void setUpdatedDt(Date updatedDt) {
        this.updatedDt = updatedDt;
    }
}