package com.crm.basic.controller.work;

public class DataDictionaryController {

}
