package com.crm.administration.model.dto;

import com.crm.bean.Role;

public class RoleDto extends Role {
}
