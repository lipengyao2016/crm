package com.crm.administration.mapper;

import com.crm.bean.user.UserRoleOrgQueryVo;
import com.crm.bean.user.UserRoleOrgs;
import com.crm.bean.user.Users;
import com.crm.bean.user.UsersCriteria;
import java.util.List;

import com.crm.bean.user.UserRoleOrgQueryVo;
import com.crm.bean.user.UserRoleOrgs;
import com.crm.bean.user.Users;
import com.crm.bean.user.UsersCriteria;
import org.apache.ibatis.annotations.Param;

public interface UsersMapper {
    int countByExample(UsersCriteria example);

    int deleteByExample(UsersCriteria example);

    int insert(Users record);

    int insertSelective(Users record);

    List<Users> selectByExample(UsersCriteria example);

    int updateByExampleSelective(@Param("record") Users record, @Param("example") UsersCriteria example);

    int updateByExample(@Param("record") Users record, @Param("example") UsersCriteria example);

    List<UserRoleOrgs> getUserRole(UserRoleOrgQueryVo userRoleOrgQueryVo);
}