package com.crm.administration.model.dto;

import com.crm.entity.Permission;

public class PermissionDto extends Permission {
}