package com.crm.assistant.model.attachment;

import java.io.Serializable;

import com.crm.bean.AttachmentKey;
import io.swagger.annotations.ApiModel;

@SuppressWarnings("serial")
@ApiModel
public class AttachmentKeyVo extends AttachmentKey implements Serializable{
 
}